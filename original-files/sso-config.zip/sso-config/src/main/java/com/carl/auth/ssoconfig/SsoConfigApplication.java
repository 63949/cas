package com.carl.auth.ssoconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoConfigApplication.class, args);
	}
}
